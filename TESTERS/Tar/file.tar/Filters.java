

import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public class Filters {

	private java.util.Properties properties = null;
	private String s_filePath = null;
	
	private String subject_filter = null;
	private String registry_file = null;
	private String server_port = null;
	private String types_file = null;
		
	/* 
	* M�todo getDocumentTypes: devuelve los tipos de documentos disponibles
	* en la aplicaci�n web.
	* Par�metros:
	* - filePath: path en el que se encuentra el fichero con los tipos de documentos
	*   de la aplicaci�n web. Debe acabar por "/" (o "\\", dependiendo
	*   del S.O.).
	* Devuelve:
	* - Vector de arrays con los datos de todos los tipos de documentos.
	*   El primer array contiene los IDs, el segundo los xls's, el tercero los
	*   valores que indican si el tratamiento es por bloques o no, y el cuarto
	*   los nombres descriptivos..
	*/
	public Vector getFilters(String filePath,String subject) {
		
		if (properties == null || s_filePath == null || !s_filePath.equals(filePath)) {
			properties = new java.util.Properties();
			try{
				java.io.FileInputStream file = new java.io.FileInputStream(filePath + "Filters.properties");
				properties.load(file);
				s_filePath = filePath;
			} catch (java.io.FileNotFoundException e1) {
				return null;			
			} catch (Exception e2) {
				return null;
			}			
			
			try {
				int filterNumber = Integer.parseInt(properties.getProperty("FilterNumber"));
				String documentFilter;

				subject_filter = new String();
				registry_file = new String();
				server_port = new String();
				types_file = new String();
				
				StringTokenizer st;
				
				for (int i = 1; i <= filterNumber; i ++) {				
					documentFilter = properties.getProperty("Filter" + i);
					//Parsear documentFilter, y meter sus componentes en la estructura
					// adecuada...
					st = new StringTokenizer(documentFilter, "|", false);
					subject_filter = st.nextToken();

					StringTokenizer stfil;
					stfil = new StringTokenizer(subject_filter, ",", false);
					
					boolean found = true;
					while(stfil.hasMoreTokens())
					{
						if(subject.indexOf(stfil.nextToken()) == -1)
						{
							found = false;
							break;
						}
						
					}

					if((found) || (subject_filter == "*"))
					{						
						registry_file = st.nextToken();
						server_port = st.nextToken();
						types_file = st.nextToken();
						break;
					}
				    
				};
				
			} catch (Exception e) {
				return null;
			}		
		}

		Vector result = new Vector();
		result.add(subject_filter);
		result.add(registry_file);
		result.add(server_port);
		result.add(types_file);

		return result;
	}
}