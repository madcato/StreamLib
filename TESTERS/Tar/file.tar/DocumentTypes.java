

import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public class DocumentTypes {

	private java.util.Properties properties = null;
	private String s_filePath = null;
	
	private int[] indexes = null;
	private int[] docIDs = null;
	private String[] xls = null;
	private String[] bloques = null;
	private String[] descriptions = null;
	private int[] typesReg = null;
		
	/* 
	* M�todo getDocumentTypes: devuelve los tipos de documentos disponibles
	* en la aplicaci�n web.
	* Par�metros:
	* - filePath: path en el que se encuentra el fichero con los tipos de documentos
	*   de la aplicaci�n web. Debe acabar por "/" (o "\\", dependiendo
	*   del S.O.).
	* Devuelve:
	* - Vector de arrays con los datos de todos los tipos de documentos.
	*   El primer array contiene los IDs, el segundo los xls's, el tercero los
	*   valores que indican si el tratamiento es por bloques o no, y el cuarto
	*   los nombres descriptivos..
	*/
	public Vector getDocumentTypes(String filePath) {
		
		if (properties == null || s_filePath == null || !s_filePath.equals(filePath)) {
			properties = new java.util.Properties();
			try{
				java.io.FileInputStream file = new java.io.FileInputStream(filePath);
				properties.load(file);
				s_filePath = filePath;
			} catch (java.io.FileNotFoundException e1) {
				return null;			
			} catch (Exception e2) {
				return null;
			}			
			
			try {
				int typesNumber = Integer.parseInt(properties.getProperty("TypesNumber"));
				String documentType;
				indexes = new int[typesNumber];
				docIDs = new int[typesNumber];
				xls = new String[typesNumber];
				bloques = new String[typesNumber];
				descriptions = new String[typesNumber];
				typesReg = new int[typesNumber];
				
				StringTokenizer st;
				
				for (int i = 1; i <= typesNumber; i ++) {				
					documentType = properties.getProperty("DocumentType" + i);
					//Parsear documentType, y meter sus componentes en la estructura
					// adecuada...
					st = new StringTokenizer(documentType, "|", false);
					indexes[i - 1] = i - 1;
				    docIDs[i - 1] = Integer.parseInt(st.nextToken());
				    xls[i - 1] = st.nextToken();
				    bloques[i - 1] = st.nextToken();
				    descriptions[i - 1] = st.nextToken();
					typesReg[i - 1] = Integer.parseInt(st.nextToken());
				};
				
			} catch (Exception e) {
				return null;
			}		
		}	
		Vector result = new Vector();
		result.add(indexes);
		result.add(docIDs);
		result.add(xls);
		result.add(bloques);
		result.add(descriptions);
		result.add(typesReg);
		return result;
	}
}